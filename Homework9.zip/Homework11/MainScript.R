library(devtools)
install_github("ngotelli/upscaler")
library(upscaler)

add_folder("Functions")
add_folder(c("CleanedData","Scripts","Plots","Outputs"))
add_folder("OriginalData")
metadata_template(file="OriginalData/MyData.csv")






build_function(c("clean_data", "extract_year","calculate_abundance", "calculate_richness", "regression_richness", "abundance_year", "histogram"))




