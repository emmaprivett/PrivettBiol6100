library(devtools)
install_github("ngotelli/upscaler")
library(upscaler)
library(pracma)
library(pryr)

add_folder("Functions")
add_folder(c("CleanedData","Scripts","Plots","Outputs"))
add_folder("OriginalData")
metadata_template(file="OriginalData/MyData.csv")
data_table_template(data_frame=NULL,file_name="Outputs/TableA.csv")

parent_directory <- "OriginalData/NEON_count-landbird"

year_folders <- list.dirs(parent_directory, full.names = TRUE, recursive = FALSE)

countdata_files <- vector()

# For loop to iterate over each year's folder
for (year_folder in year_folders) {
  file_list <- list.files(year_folder, pattern = "countdata.*\\.csv$", full.names = TRUE)
  if (length(file_list) > 0) {
    countdata_files <- c(countdata_files, file_list)
  }
}

# Print the collected list of count data CSV file paths
print(countdata_files)



#pseudocode to build functions

build_function(c("clean_data", "extract_year","calculate_abundance", "calculate_richness", "regression_richness", "abundance_year", "histogram"))

fxs <- list.files("Functions")

for (i in 1:length(fxs)){

  fx <- paste0("Functions/", fxs[i])

  source(fx)
}

#empty dataframe
. <- rep(NA, year_folder, times=1)

stats <- data.frame(filename=.,
                    abundance=.,
                    richness=.,
                    year=.)

regression <- data.frame(estimate=c(NA,NA),
                         std.err=c(NA,NA),
                         t.value=c(NA,NA),
                         p.value=c(NA,NA))

rownames(regression) <- c("intercept", "abundance")



# batch process for each folder

for (i in 1:length(countdata_files)){

  name_i <- countdata_files[i]

  df_i <- clean_data(countdata_files[i])

  stats[i,] <- list(name_i, calculate_abundance(df_i), calculate_richness(df_i), extract_year(name_i))

}

stats[,2:4]
