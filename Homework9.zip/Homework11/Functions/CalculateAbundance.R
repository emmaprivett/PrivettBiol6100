# --------------------------------------
# FUNCTION calculate_abundance
# required packages: none
# description:
# inputs:
# outputs:
########################################
calculate_abundance <- function(x=NULL,y=NULL){

# assign parameter defaults
if (is.null(x) | is.null(y)) {
  x <- runif(10)
  y <- runif(10)
}

# function body



return(print('...checking function: calculate_abundance()'))

} # end of function calculate_abundance
# --------------------------------------
# calculate_abundance()
