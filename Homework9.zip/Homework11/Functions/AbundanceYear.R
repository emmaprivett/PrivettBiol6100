# --------------------------------------
# FUNCTION abundance_year
# required packages: none
# description:
# inputs:
# outputs:
########################################
abundance_year <- function(x=NULL,y=NULL){

# assign parameter defaults
if (is.null(x) | is.null(y)) {
  x <- runif(10)
  y <- runif(10)
}

# function body



return(print('...checking function: abundance_year()'))

} # end of function abundance_year
# --------------------------------------
# abundance_year()
