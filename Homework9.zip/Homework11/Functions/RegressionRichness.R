# --------------------------------------
# FUNCTION regression_richness
# required packages: none
# description:
# inputs:
# outputs:
########################################
regression_richness <- function(x=NULL,y=NULL){

# assign parameter defaults
if (is.null(x) | is.null(y)) {
  x <- runif(10)
  y <- runif(10)
}

# function body



return(print('...checking function: regression_richness()'))

} # end of function regression_richness
# --------------------------------------
# regression_richness()
