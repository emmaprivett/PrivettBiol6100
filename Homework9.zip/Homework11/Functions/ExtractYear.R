# --------------------------------------
# FUNCTION extract_year
# required packages: none
# description:
# inputs:
# outputs:
########################################
extract_year <- function(x=NULL,y=NULL){

# assign parameter defaults
if (is.null(x) | is.null(y)) {
  x <- runif(10)
  y <- runif(10)
}

# function body



return(print('...checking function: extract_year()'))

} # end of function extract_year
# --------------------------------------
# extract_year()
