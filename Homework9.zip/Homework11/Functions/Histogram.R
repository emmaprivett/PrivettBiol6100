# --------------------------------------
# FUNCTION histogram
# required packages: none
# description:
# inputs:
# outputs:
########################################
histogram <- function(x=NULL,y=NULL){

# assign parameter defaults
if (is.null(x) | is.null(y)) {
  x <- runif(10)
  y <- runif(10)
}

# function body



return(print('...checking function: histogram()'))

} # end of function histogram
# --------------------------------------
# histogram()
